#pragma once
#include "AudioBehavior.hpp"
#include <vector>
#include <string>
#include "ASTNode.hpp"

class BehaviorLoader {
public:
    // Scan folder for .audio (or .yaml) files and build raw behaviors
    static std::vector<AudioBehavior> LoadAudioBehaviorsFromFolder(const std::string& folderPath);

private:
    static Condition  parseCondition(const std::string& string);
    static Expression parseExpression(const std::string& string);
    static std::unique_ptr<Node> ParseNode(const ASTNode& node);
};