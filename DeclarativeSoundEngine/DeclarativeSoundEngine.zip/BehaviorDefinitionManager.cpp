#include "pch.h"
#include "BehaviorDefinitionManager.hpp"
#include "BehaviorLoader.hpp"
#include <iostream>



void BehaviorDefinitionManager::LoadFilesFromFolder(const std::string& path)
{
    auto behaviors = BehaviorLoader::LoadAudioBehaviorsFromFolder(path);
    std::cout << "after BehaviorLoader::LoadAudioBehaviorsFromFolder" << std::endl;
    // reserve capacity to avoid reallocations during push_back
    matchdefs.clear();
    matchdefs.reserve(behaviors.size());
    playdefs.clear();
    playdefs.reserve(behaviors.size());

    std::cout << "before loop\n";
    for (auto& b : behaviors) {
        // 1) Build and emplace a MatchDefinition on the stack
        MatchDefinition md;
        md.id = b.id;
        md.name = b.name;
        md.matchTags = b.matchTags;
        md.matchConditions = b.matchConditions;
        md.parameters = b.parameters;


        std::cout << "before pushback\n";
        matchdefs.push_back(std::move(md));

        // 2) Build and emplace a PlayDefinition with an owned clone of the node-tree
        PlayDefinition pd;
        pd.id = b.id;
        std::cout << "before clone\n";
    
        pd.rootNode = b.rootSoundNode->clone();    // <-- your deep-copy method
        playdefs.push_back(std::move(pd));
    }

    std::cout << "...done\n";
}


std::vector<PlayDefinition>& BehaviorDefinitionManager::GetPlayDefs()
{
    return playdefs;
}

std::vector<MatchDefinition>& BehaviorDefinitionManager::GetMatchDefs()
{
    return matchdefs;
}
