#pragma once
#include <string>
#include <unordered_map>
#include "AudioBuffer.hpp"
#include <future>


class AudioBufferManager {
public:
	AudioBufferManager();
	~AudioBufferManager();
	AudioBuffer* Load(const std::string& path);
	//std::future<AudioBuffer*> LoadAsync(const std::string& path);
	void         Unload(const std::string& path);
	void         PurgeUnused();
	size_t       GetMemoryUsage();
private:
	std::mutex mutex;
	std::unordered_map<std::string, std::pair<AudioBuffer, int /*refcount*/>> cache;
	std::list<std::string> lruList;
	size_t currentMemoryUsage;
};
