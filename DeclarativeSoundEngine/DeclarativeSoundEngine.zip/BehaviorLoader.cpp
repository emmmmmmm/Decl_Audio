#include "pch.h"
#include "BehaviorLoader.hpp"
#include "ASTBuilder.hpp"
#include "BehaviorResolver.hpp"
#include "AudioBehavior.hpp"
#include <filesystem>
#include <yaml-cpp/yaml.h>
#include "Log.hpp"
#include <memory>
#include <vector>
#include <unordered_map>
#include <regex>

std::vector<AudioBehavior> BehaviorLoader::LoadAudioBehaviorsFromFolder(const std::string& folderPath) {
    // Step 1: parse raw ASTs
    std::vector<RawAudioBehavior> raws;
    for (auto& entry : std::filesystem::directory_iterator(folderPath)) {
        if (!entry.is_regular_file()) continue;
        auto path = entry.path();
        auto ext = path.extension().string();
        if (ext == ".audio" || ext == ".yaml") {
            try {
                YAML::Node yamlRoot = YAML::LoadFile(path.string());
                ASTNode ast = ASTBuilder::build(yamlRoot);
                RawAudioBehavior raw;
                // extract ID if present
                if (ast.map.count("id") && ast.map.at("id").isScalar()) {
                    raw.id = ast.map.at("id").scalar;
                }
                else {
                    raw.id = path.stem().string();
                }
                raw.root = std::move(ast);
                raws.push_back(std::move(raw));
            }
            catch (const std::exception& e) {
                LogMessage(std::string("YAML parse error in ") + path.string() + ": " + e.what(), LogCategory::BehaviorLoader, LogLevel::Error);
            }
        }
    }

    // Step 2: resolve inheritance/overrides
    BehaviorResolver::resolveAll(raws);

    // Step 3: instantiate into final AudioBehavior structs
    std::vector<AudioBehavior> behaviors;
    behaviors.reserve(raws.size());
    for (auto& raw : raws) {
        AudioBehavior b;
        b.id = raw.id;
        // flatten matchTags
        if (auto it = raw.root.map.find("matchTags"); it != raw.root.map.end() && it->second.isSeq()) {
            for (auto& tagAst : it->second.seq)
                b.matchTags.push_back(tagAst.scalar);
        }
        // flatten matchConditions
        if (auto it = raw.root.map.find("matchConditions"); it != raw.root.map.end() && it->second.isSeq()) {
            for (auto& cAst : it->second.seq)
                b.matchConditions.push_back(parseCondition(cAst.scalar));
        }
        // flatten parameters
        if (auto it = raw.root.map.find("parameters"); it != raw.root.map.end() && it->second.isMap()) {
            for (auto& kv : it->second.map)
                b.parameters[kv.first] = parseExpression(kv.second.scalar);
        }
        // build sound graph
        if (auto it = raw.root.map.find("soundNode"); it != raw.root.map.end()) {
            b.rootSoundNode = ParseNode(it->second);
        }
        behaviors.emplace_back(std::move(b));
    }

    return behaviors;
}

Condition BehaviorLoader::parseCondition(const std::string& string)
{
    return Condition(string);
}

Expression BehaviorLoader::parseExpression(const std::string& string)
{
    return Expression(string);
}

std::unique_ptr<Node> BehaviorLoader::ParseNode(const ASTNode& node )
{
    return std::unique_ptr<Node>();
}
