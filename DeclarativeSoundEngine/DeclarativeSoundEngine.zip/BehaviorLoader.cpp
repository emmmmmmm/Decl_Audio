﻿// BehaviorLoader.cpp
#include "pch.h"
#include "BehaviorLoader.hpp"
#include "AudioBehavior.hpp"
#include "ParserUtils.hpp"
#include "Log.hpp"
#include <filesystem>
#include <yaml-cpp/yaml.h>

std::vector<AudioBehavior> BehaviorLoader::LoadAudioBehaviorsFromFolder(const std::string& folderPath) {
    // 1. Load raw YAML definitions
    std::vector<YAML::Node> yamlBehaviors;
    for (auto& entry : std::filesystem::directory_iterator(folderPath)) {
        if (!entry.is_regular_file()) continue;
        const auto ext = entry.path().extension().string();
        if (ext == ".audio" || ext == ".yaml") {
            try {
                YAML::Node root = YAML::LoadFile(entry.path().string());
                if (root.IsSequence()) {
                    for (auto node : root) yamlBehaviors.push_back(node);
                }
                else {
                    yamlBehaviors.push_back(root);
                }
            }
            catch (const std::exception& e) {
                LogMessage("YAML parse error in " + entry.path().string() + ": " + e.what(),
                    LogCategory::BehaviorLoader, LogLevel::Error);
            }
        }
    }

    // 2. Register and parse BehaviorDefs
    ParserUtils::Context ctx;
    struct RawDef { std::string id; YAML::Node node; };
    std::vector<RawDef> rawDefs;
    rawDefs.reserve(yamlBehaviors.size());
    for (auto& beh : yamlBehaviors) {
        rawDefs.push_back({ beh["id"].as<std::string>(""), beh });
    }

    std::vector<std::unique_ptr<BehaviorDef>> definitions;
    definitions.reserve(rawDefs.size());
    for (auto& rd : rawDefs) {
        auto def = std::make_unique<BehaviorDef>();
        def->id = rd.id;
        def->busIndex = rd.node["bus"].as<int>(0);
        if (rd.node["matchTags"]) for (auto tag : rd.node["matchTags"]) def->matchTags.push_back(tag.as<std::string>());
        if (rd.node["matchConditions"]) for (auto cond : rd.node["matchConditions"]) def->matchConditions.push_back(Condition(cond.as<std::string>()));
        if (rd.node["volume"]) def->rootVolume = Expression(rd.node["volume"].as<std::string>());
        if (rd.node["onStart"])  def->onStart = std::unique_ptr<Node>(ParserUtils::ParseNode(rd.node["onStart"], ctx));
        if (rd.node["onActive"]) def->onActive = std::unique_ptr<Node>(ParserUtils::ParseNode(rd.node["onActive"], ctx));
        if (rd.node["onEnd"])    def->onEnd = std::unique_ptr<Node>(ParserUtils::ParseNode(rd.node["onEnd"], ctx));
        ctx.definitions[def->id] = def->onActive.get();
        definitions.push_back(std::move(def));
    }

    // 3. Resolve references
    for (auto& pr : ctx.unresolvedRefs) {
        auto it = ctx.definitions.find(pr.second);
        if (it != ctx.definitions.end()) pr.first->resolve(it->second);
        else LogMessage("Unresolved reference '" + pr.second + "'", LogCategory::BehaviorLoader, LogLevel::Error);
    }
    ctx.unresolvedRefs.clear();

    // 4. Build AudioBehavior list
    std::vector<AudioBehavior> behaviors;
    behaviors.reserve(definitions.size());
    for (auto& defPtr : definitions) {
        AudioBehavior b;
        b.name = defPtr->id;
        b.busIndex = defPtr->busIndex;
        b.matchTags = defPtr->matchTags;
        b.matchConditions = defPtr->matchConditions;
        b.rootVolume = defPtr->rootVolume;
        b.onStart = std::move(defPtr->onStart);
        b.onActive = std::move(defPtr->onActive);
        b.onEnd = std::move(defPtr->onEnd);
        behaviors.push_back(std::move(b));
    }

    return behaviors;
}
