﻿// AudioCore.cpp
#include "pch.h"
#include "AudioCore.hpp"
#include "Log.hpp"
#include "IBehaviorDefinition.hpp"
#include <iostream>
#include "AudioDeviceMiniAudio.hpp"
#include <algorithm>
#include <array>  

void BehaviorInstance::Update(const ValueMap& params, AudioBufferManager* bufMgr, uint8_t busIdx, float dt)
{
	if (!onActive)
		return;

	constexpr float FADE_SEC = 0.05f;          // 50-ms fade
	float stepFactor = (std::min)(dt / FADE_SEC, 1.0f);  // dt is control-tick

	std::vector<SoundLeaf> desired;
	CollectLeaves(*onActive, params, 1.0f, busIdx, desired, bufMgr);

	// start new
	for (auto& leaf : desired) {
		if (!leaf.buf) continue; // failed load, skip
		if (!HasVoice(leaf.src))
			StartVoice(leaf, busIdx);
	}

	// fade-out missing
	for (auto& v : voices)
		if (std::none_of(desired.begin(), desired.end(),
			[&](const SoundLeaf& l) { return l.src == v.source; }))
			v.targetVol = 0.0f;

	// 2) ramp
	for (Voice& v : voices) {
		float diff = v.targetVol - v.currentVol;
		v.currentVol += diff * stepFactor;           // 0 → 1 fade-in, 1 → 0 fade-out
	}
	// 3) prune
	auto endIt = std::remove_if(voices.begin(), voices.end(),
		[&](const Voice& v)
		{
			bool done = !v.loop && v.playhead >= v.buffer->GetFrameCount();
			bool silent = (v.currentVol < 0.001f && v.targetVol == 0.f);
			return done || silent;
		});
	voices.erase(endIt, voices.end());
}


void BehaviorInstance::CollectLeaves(const Node& n,
	const ValueMap& params,
	float              inGain,
	uint8_t            bus,
	std::vector<SoundLeaf>& out,
	AudioBufferManager* bufMgr)
{
	float here = inGain * n.volume.eval(params);

	switch (n.type)
	{
	case NodeType::Sound: {
		const SoundNode& sn = static_cast<const SoundNode&>(n);
		AudioBuffer* buf;

		if (!bufMgr->TryLoad(sn.sound, buf)) {

			return;          // silent fail
		}
		out.push_back({ &sn, buf, here, sn.loop, bus });
		return;
	}

	case NodeType::Layer:
		for (auto& c : n.children)
			CollectLeaves(*c, params, here, bus, out, bufMgr);
		return;

	case NodeType::Random: {
		auto& rn = static_cast<const RandomNode&>(n);
		size_t idx = rn.pickOnce();               // RandomNode remembers choice
		CollectLeaves(*rn.children[idx], params, here, bus, out, bufMgr);
		return;
	}

	case NodeType::Blend: {
		const BlendNode& bn = static_cast<const BlendNode&>(n);
		float x = params.HasValue(bn.parameter) ? params.GetValue(bn.parameter) : 0.f;

		auto w = bn.weights(x);
		if (w[0].first) CollectLeaves(*w[0].first, params, here * w[0].second, bus, out, bufMgr);
		if (w[1].first) CollectLeaves(*w[1].first, params, here * w[1].second, bus, out, bufMgr);
		return;
	}

	case NodeType::Select: {
		const SelectNode& sn = static_cast<const SelectNode&>(n);
		std::string val = params.HasValue(sn.parameter)
			? std::to_string(int(params.GetValue(sn.parameter)))
			: "";
		if (const Node* child = sn.pick(val))
			CollectLeaves(*child, params, here, bus, out, bufMgr);
		return;
	}

	default: return;
	}
}



AudioCore::AudioCore(IBehaviorDefinition* defsProvider, CommandQueue* fromManager, CommandQueue* toManager)
	: defsProvider(defsProvider), inQueue(fromManager), outQueue(toManager)
{
	audioBufferManager = new AudioBufferManager();
	device = std::make_unique<AudioDeviceMiniaudio>(outputChannels, sampleRate, bufferFrames);

	device->SetRenderCallback(
		[this](float* output, int frameCount) {
			RenderCallback(output, frameCount); });

	// Create Master Bus
	buses.clear();
	buses.push_back({ std::vector<float>(bufferFrames * outputChannels), {} }); // master

}
AudioCore::~AudioCore() {
	delete audioBufferManager;
}




void AudioCore::Update() {
	// this function will loop indefinitely in the future! 
	auto now = std::chrono::steady_clock::now();
	float dt = std::chrono::duration<float>(now - lastUpdate).count();
	lastUpdate = now;

	AdvancePlayheads();
	ProcessCommands();
	ProcessActiveSounds(dt);
	TakeSnapshot();
}

void AudioCore::AdvancePlayheads()
{
	uint32_t step = pendingFrames.exchange(0, std::memory_order_acquire);
	if (step == 0) return;

	for (auto& [eid, ed] : entityMap)
		for (auto& inst : ed.instances)
			for (auto& v : inst.voices) {
				size_t len = v.buffer->GetFrameCount();
				if (v.loop)
					v.playhead = (v.playhead + step) % len;
				else
					v.playhead = (std::min)(v.playhead + step, len);
			}
}


// build a fresh read‐only snapshot for render
void AudioCore::TakeSnapshot()
{
	int w = 1 - curSnap.load(std::memory_order_relaxed);   // back buffer
	Snapshot& s = snap[w];
	s.voices.clear();

	/* ---------- BUS GAIN EVALUATION ---------- */

	s.busGain.resize(buses.size());

	// Build reverse lookup: bus index → entity params*
	std::vector<const ValueMap*> paramOfBus(buses.size(), nullptr);
	for (auto& [eid, idx] : entityBus)
		paramOfBus[idx] = &entityMap[eid].params; // sub-bus
	// master (0) could use global params later; for now nullptr = empty

	for (size_t i = 0; i < buses.size(); ++i) {
		const ValueMap empty;
		const ValueMap* pv = paramOfBus[i] ? paramOfBus[i] : &empty;
		s.busGain[i] = buses[i].volume.eval(*pv); // Expression → float
	}

	/* ---------- FLATTEN VOICES ---------- */

	for (auto& [eid, ed] : entityMap)
		for (auto& inst : ed.instances)
			for (auto& v : inst.voices)
				s.voices.push_back(
					VoiceSnap{ v.buffer,
							   v.playhead,
							   v.currentVol,
							   v.loop,
							   uint8_t(v.busIndex) });


	// DEBUG: 
	LogMessage("Snapshot: voices=" + std::to_string(s.voices.size()) +
		" buses=" + std::to_string(s.busGain.size()),
		LogCategory::AudioCore, LogLevel::Debug);

	for (auto& v : s.voices)
		LogMessage( //"  buf=" + // v.buf->GetName() +      // helper you already have
			" gain=" + std::to_string(v.gain) +
			" loop=" + (v.loop ? "1" : "0") +
			" bus=" + std::to_string(v.bus),
			LogCategory::AudioCore, LogLevel::Debug);

	curSnap.store(w, std::memory_order_release); // publish
}
void AudioCore::ProcessCommands() {
	Command cmd;
	while (inQueue->pop(cmd)) {
		LogMessage("ProcessCommands: " + cmd.GetTypeName(), LogCategory::AudioCore, LogLevel::Debug);

		switch (cmd.type) {
		case CommandType::StartBehavior:		HandleStartBehavior(cmd); break;
		case CommandType::StopBehavior:			HandleStopBehavior(cmd); break;
		case CommandType::ValueUpdate:			HandleValueUpdate(cmd); break;
		case CommandType::RefreshDefinitions:	RefreshDefinitions(); break;
		case CommandType::BusGainUpdate:        HandleBusGain(cmd);break;
		default: break;
		}
	}

	// DEBUG
	LogMessage("DEBUG ENTITYMAP:",
		LogCategory::AudioCore, LogLevel::Debug);
	for (auto& [eid, ed] : entityMap) {
		LogMessage("Entity '" + eid + "' — params:" +
			std::to_string(ed.params.GetAllValues().size()) +
			" instances:" + std::to_string(ed.instances.size()),
			LogCategory::AudioCore, LogLevel::Debug);

		for (auto& inst : ed.instances) {
			LogMessage("  inst id=" + std::to_string(inst.id) +
				" phase=" + std::to_string(int(inst.phase)) +
				" voices=" + std::to_string(inst.voices.size()),
				LogCategory::AudioCore, LogLevel::Debug);
		}
	}
	LogMessage("-----",
		LogCategory::AudioCore, LogLevel::Debug);


}

void AudioCore::RefreshDefinitions() {
	for (auto& p : defsProvider->GetPlayDefs()) {
		prototypes[p.id] = std::move(p);
	}
	LogMessage("Audiocore definitions refreshed!", LogCategory::AudioCore, LogLevel::Debug);
}
void AudioCore::HandleStartBehavior(const Command& cmd)
{
	LogMessage("AudioCore: StartBehavior id="
		+ std::to_string(cmd.behaviorId),
		LogCategory::AudioCore, LogLevel::Info);

	// 0) locate prototype
	auto p = prototypes.find(cmd.behaviorId);
	if (p == prototypes.end()) {
		LogMessage("StartBehavior: unknown PlayDefinition id "
			+ std::to_string(cmd.behaviorId),
			LogCategory::AudioCore, LogLevel::Warning);
		return;

	}

	// 1) ensure entity slot
	auto& entity = entityMap[cmd.entityId];   // auto-creates

	// 2) build fresh instance
	BehaviorInstance inst;
	inst.id = p->second.id;
	inst.phase = Phase::Start;

	inst.onStart = p->second.onStart ? p->second.onStart->clone() : nullptr;
	inst.onActive = p->second.onActive ? p->second.onActive->clone() : nullptr;
	inst.onEnd = p->second.onEnd ? p->second.onEnd->clone() : nullptr;

	inst.paramExpr = p->second.parameters;    // root-level expressions

	// 3) add to entity
	entity.instances.push_back(std::move(inst));

	// 4) no voice creation here; ProcessActiveSounds() will do it
}

void AudioCore::HandleStopBehavior(const Command& cmd) {
	LogMessage("AudioCore: StopBehavior called for " + cmd.soundName, LogCategory::AudioCore, LogLevel::Info);
	// todo: stop sound, cleanup from activebehaviors
}


void AudioCore::HandleValueUpdate(const Command& cmd) {
	LogMessage("AudioCore: ValueUpdate " + cmd.key + " = " + std::to_string(cmd.value), LogCategory::AudioCore, LogLevel::Info);

	entityMap[cmd.entityId].params.SetValue(cmd.key, cmd.value);

}

void AudioCore::ProcessActiveSounds(float dt)
{
	for (auto& [eid, data] : entityMap) {

		for (auto inst = data.instances.begin(); inst != data.instances.end(); )
		{
			switch (inst->phase)
			{
			case Phase::Start:
			{
				if (inst->voices.empty() && inst->onStart) {

					std::vector<SoundLeaf> tmp;
					inst->CollectLeaves(*inst->onStart, data.params, 1.0f,
						GetOrCreateBus(eid), tmp, audioBufferManager);
					for (auto& leaf : tmp) inst->StartVoice(leaf, leaf.bus);
				}

				// if (!inst->voices.empty() && AllFinished(inst->voices))

				inst->phase = Phase::Active;
				// Active voices will be created next CollectLeaves() pass
			}
			
			
			break;

			case Phase::Active:
				// voices updated/diffed by CollectLeaves() 
				inst->Update(data.params, audioBufferManager, GetOrCreateBus(eid), dt);
				break;

			case Phase::Ending:
				if (AllFinished(inst->voices)) {
					inst = data.instances.erase(inst);      // remove done instance
					continue;                               // stay valid
				}
				break;
			}
			++inst;
		}
	}
}

// Helper: find the first SoundNode in a node-tree
SoundNode* AudioCore::FindFirstSoundNode(Node* node) {
	if (!node)
		return nullptr;
	if (auto* sn = dynamic_cast<SoundNode*>(node)) {
		return sn;
	}
	for (auto& childPtr : node->children) {
		if (auto* found = FindFirstSoundNode(childPtr.get())) {
			return found;
		}
	}
	return nullptr;
}



// MIXING


int AudioCore::GetOrCreateBus(const std::string& entityId) {
	auto it = entityBus.find(entityId);
	if (it != entityBus.end()) return it->second;
	// allocate new sub‐bus
	int newIndex = (int)buses.size();
	buses.push_back({ std::vector<float>(bufferFrames * outputChannels), {} });
	entityBus.emplace(entityId, newIndex);
	return newIndex;
}

void AudioCore::ClearBusBuffers() {
	for (auto& bus : buses) {
		std::fill(bus.buffer.begin(), bus.buffer.end(), 0.0f);
	}
}

void AudioCore::HandleBusGain(const Command& cmd)
{
	int idx = GetOrCreateBus(cmd.entityId);
	buses[idx].volume = Expression(cmd.strValue); // literal "0.8" or "distance*0.5"
}


void AudioCore::RenderCallback(float* out, int frames)
{
	int r = curSnap.load(std::memory_order_acquire);
	const Snapshot& s = snap[r];
	uint64_t blockStart = globalSampleCounter;          // snapshot moment


	ClearBusBuffers(); // zero bus buffers

	// mix voices
	for (auto& vs : s.voices) {
		auto* pcm = vs.buf->GetData();
		int   ch = vs.buf->GetChannelCount();
		size_t len = vs.buf->GetFrameCount();
		uint64_t basePos = blockStart - vs.startSample;

		auto& bus = buses[vs.bus].buffer;

		for (int i = 0; i < frames; ++i) {
			uint64_t pos = basePos + i;
			float s0 = 0;
			if (pos < len) {
				size_t idx = (pos) % len;
				s0 = pcm[idx * ch] * vs.gain;              // gain already ramped

			}
			else if (vs.loop) {
				size_t idx = (pos % len);
				s0 = pcm[idx * ch] * vs.gain;
			}
			// else: silent once we run past the tail

			// mix to bus
			for (int c = 0; c < outputChannels; ++c)
				bus[i * outputChannels + c] += s0;
		}
	}

	// 1) fold leaf → root using busGain[i]
	for (int bus = int(buses.size()) - 1; bus > 0; --bus) {
		float gain = s.busGain[bus];
		int   parent = buses[bus].parent;
		auto& in = buses[bus].buffer;
		auto& dst = buses[parent].buffer;
		for (size_t i = 0; i < dst.size(); ++i)
			dst[i] += in[i] * gain;
	}

	// 2) now every bus buffer holds its *final* audio for this block.
	//    apply sends (fan-outs) in a separate loop.

	for (size_t bus = 1; bus < buses.size(); ++bus) {
		for (Bus::Routing r : buses[bus].sends) {
			auto& src = buses[bus].buffer;
			auto& dst = buses[r.dst].buffer;
			for (size_t i = 0; i < dst.size(); ++i)
				dst[i] += src[i] * r.gain;         // post-fader send
		}
	}

	std::memcpy(out, buses[0].buffer.data(),
		size_t(frames * outputChannels) * sizeof(float));

	// increment pendingFrames
	pendingFrames.fetch_add(static_cast<uint32_t>(frames),
		std::memory_order_relaxed);

	globalSampleCounter += frames;
}
