#include "pch.h"
#include "BehaviorResolver.hpp"
#include <unordered_map>
#include <vector>
#include <string>
ASTNode BehaviorResolver::mergeBehaviorAST(const ASTNode& parent, const ASTNode& child) {
    ASTNode out = parent;
    for (const auto& kv : child.map) {
        const auto& key = kv.first;
        const ASTNode& cv = kv.second;
        if (key == "inherit") continue;
        if (key == "overrides" && cv.isMap()) {
            // Deep merge override subtree
            // (Assume a separate utility mergeAST handles nested maps)
            out = /* mergeAST(out, cv) */ out;
            continue;
        }
        auto pit = parent.map.find(key);
        if (pit == parent.map.end()) {
            out.map[key] = cv;
            continue;
        }
        const ASTNode& pv = pit->second;
        // Sequence merge
        if (pv.isSeq() && cv.isSeq()) {
            ASTNode merged = pv;
            merged.seq.insert(merged.seq.end(), cv.seq.begin(), cv.seq.end());
            out.map[key] = std::move(merged);
        }
        // Scalar relative or override
        else if (pv.isScalar() && cv.isScalar()) {
            const std::string& cs = cv.scalar;
            if ((cs[0] == '+' || cs[0] == '-' || cs[0] == '*')) {
                out.map[key].scalar = /* evaluateRelative(pv.scalar, cs) */ cs;
            }
            else {
                out.map[key] = cv;
            }
        }
        // Fallback replace
        else {
            out.map[key] = cv;
        }
    }
    return out;
}

void BehaviorResolver::resolveAll(std::vector<RawAudioBehavior>& behaviors) {
    // Example stub: for each behavior with inherit, find parent and merge
    for (auto& b : behaviors) {
        if (!b.root.map.count("inherit")) continue;
        std::string parentId = b.root.map.at("inherit").scalar;
        // find parent RawAudioBehavior* p ... then:
        // b.root = mergeBehaviorAST(p->root, b.root);
    }
}