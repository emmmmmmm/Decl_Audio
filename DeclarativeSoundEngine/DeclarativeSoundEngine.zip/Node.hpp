#pragma once
#include <string>
#include <vector>
#include <memory>

struct Node {
    // �
};