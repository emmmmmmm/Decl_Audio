// ParserUtils.cpp
#include "pch.h"
#include "ParserUtils.hpp"
#include "Node.hpp"
#include <stdexcept>

namespace ParserUtils {

	std::string ExtractCoreKey(const YAML::Node& mapNode) {
		for (auto it = mapNode.begin(); it != mapNode.end(); ++it) {
			std::string key = it->first.Scalar();
			if (key == "sound" || key == "delay" || key == "random" || key == "sequence" ||
				key == "blend" || key == "select" || key == "loop" || key == "parallel") {
				return key;
			}
		}
		throw std::runtime_error("Unknown node type in map");
	}

	ModifierMap ExtractModifiers(const YAML::Node& mapNode) {
		ModifierMap mods;
		if (mapNode["volume"])   mods.volume = mapNode["volume"].as<std::string>();
		if (mapNode["pitch"])    mods.pitch = mapNode["pitch"].as<std::string>();
		mods.loop = mapNode["loop"] ? mapNode["loop"].as<bool>() : false;
		return mods;
	}

	YAML::Node ExtractChildren(const YAML::Node& mapNode) {
		if (mapNode["nodes"]) {
			return mapNode["nodes"];
		}
		for (auto it = mapNode.begin(); it != mapNode.end(); ++it) {
			if (it->second.IsSequence()) {
				return it->second;
			}
		}
		return YAML::Node();
	}

	Node* ParseNode(const YAML::Node& yamlNode, Context& ctx) {
		Node* node = nullptr;
		ModifierMap mods;

		if (yamlNode.IsScalar()) {
			std::string val = yamlNode.as<std::string>();
			auto it = ctx.definitions.find(val);
			if (it != ctx.definitions.end()) {
				auto ref = new ReferenceNode(val);
				ctx.unresolvedRefs.emplace_back(ref, val);
				node = ref;
			}
			else {
				node = new SoundNode(val);
			}
		}
		else if (yamlNode.IsSequence()) {
			auto seq = new SequenceNode();
			for (const auto& child : yamlNode) {
				seq->addChild(ParseNode(child, ctx));
			}
			node = seq;
		}
		else if (yamlNode.IsMap()) {
			std::string key = ExtractCoreKey(yamlNode);
			mods = ExtractModifiers(yamlNode);
			YAML::Node children = ExtractChildren(yamlNode);

			if (key == "sound") {
				node = new SoundNode(yamlNode[key].as<std::string>());
			}
			else if (key == "delay") {
				node = new DelayNode(yamlNode[key].as<std::string>());
			}
			else if (key == "sequence") {
				auto seq = new SequenceNode();
				if (children) for (const auto& child : children) seq->addChild(ParseNode(child, ctx));
				node = seq;
			}
			else if (key == "parallel") {
				auto par = new ParallelNode();
				if (children) for (const auto& child : children) par->addChild(ParseNode(child, ctx));
				node = par;
			}
			else if (key == "random") {
				auto rnd = new RandomNode();
				if (children) for (const auto& child : children) rnd->addChild(ParseNode(child, ctx));
				node = rnd;
			}
			else if (key == "blend") {
				auto bs = new BlendNode();
				bs->parameter = yamlNode["parameter"].as<std::string>();
				if (children) {
					for (const auto& item : children) {
						float at = item["at"].as<float>();
						Node* childNode = ParseNode(item, ctx);

						bs->addCase(at, childNode);
					}
				}
				node = bs;
			}
			else if (key == "select") {
				auto bs = new SelectNode();
				bs->parameter = yamlNode["parameter"].as<std::string>();
				if (children) {
					for (const auto& item : children) {
						float at = item["at"].as<float>();
						Node* childNode = ParseNode(item, ctx);
						bs->addCase(at, childNode);
					}
				}
				node = bs;
			}

			else if (key == "loop") {
				YAML::Node sub = yamlNode[key];
				auto childUP = std::unique_ptr<Node>(ParseNode(sub, ctx));
				node = new LoopNode(std::move(childUP));
			}
			else {
				throw std::runtime_error("Unhandled coreKey: " + key);
			}
		}
		else {
			throw std::runtime_error("Invalid YAML node type");
		}

		if (mods.volume) node->setVolume(mods.volume.value());
		if (mods.pitch)  node->setPitch(mods.pitch.value());

		if (mods.loop) {
			// take ownership of the raw pointer in a unique_ptr
			std::unique_ptr<Node> owned(node);
			// construct a LoopNode that now owns that subtree
			auto loopNode = std::make_unique<LoopNode>(std::move(owned));
			// release the raw pointer from unique_ptr so we return the LoopNode*
			node = loopNode.release();
		}

		node = NormalizeLoops(node);
		return node;
	}

	Node* NormalizeLoops(Node* root) {
		if (auto loopNode = dynamic_cast<LoopNode*>(root)) {
			if (auto inner = dynamic_cast<LoopNode*>(loopNode->getChild())) {
				return NormalizeLoops(inner);
			}
		}
		for (auto& child : root->getChildren())
			NormalizeLoops(child.get());
		return root;
	}

} // namespace ParserUtils
